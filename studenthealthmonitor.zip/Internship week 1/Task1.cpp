#include <iostream>
#include <string>
#include <cmath>
using namespace std;

int main() {
    string names[30];
    float weights_start[30];
    float weights_end[30 ];
    float weight_diff[30]; 

    for(int i = 0; i < 30; i++) {
        string name;
        float weight;

        while(true) {
            cout << "Enter the name of the pupil"<<" "<< i+1<< " : ";
            cin >> name;
            cout<<endl;

            bool isUnique = true;
            for(int j = 0; j < i; j++) {
                if(names[j] == name) {
                    isUnique = false; 
                    break;
                }
            }

            if(isUnique) {
                names[i] = name;
                break;
            } else {
                cout << "Name already exists. Please enter a unique name.\n";
            }
        }

        while(true) {
            cout << "Enter the weight of the pupil: ";
            cin >> weight;
            cout<<endl;
            if(weight > 0 && weight < 200) {
                weights_start[i] = weight;
                break;
            } else {
                cout << "Invalid weight. Please enter a weight between 0 and 200 kg.\n";
            }
        }
    
     while(true) {
            cout << "Enter the weight of pupil " << i+1 << " at the end of term: ";
            cin >> weight;
            cout<<endl;   
            if(weight > 0 && weight < 200) {
                weights_end[i] = weight;
                break;
            } else {
                cout << "Invalid weight. Please enter a weight between 0 and 200 kg.\n";
            }
        }
           weight_diff[i] = weights_end[i] - weights_start[i];
    }
    cout<<endl;
     for(int i = 0; i < 30; i++) {
        cout << "Pupil " << i+1 << ": Name = " << names[i] << ", Start Weight = " << weights_start[i] << " kg, End Weight = " << weights_end[i] << " kg, Weight Difference = " << weight_diff[i] << " kg\n";
        if(fabs(weight_diff[i]) > 2.5) {
            cout << "Note: " << names[i] << " has a weight difference of more than 2.5 kg. This is a " << (weight_diff[i] > 0 ? "rise" : "fall") << ".\n";
        }
    }

    return 0;
}